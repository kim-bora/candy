 

//탑 이동버튼

jQuery(document).ready(function(){
	jQuery('.top_scroll').click(function(){	
	jQuery('html, body').animate({
		scrollTop:0
		},500);
	});
});
  