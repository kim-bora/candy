         



    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires + '; Path=/;';
    }

    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    }

    function delete_cookie(name) {
        document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    }


    








    jQuery(window).ready(function() {
        function loop() {
            jQuery('.join_point').animate ({ top: '+=5' }, 200) 
                .animate({ top: '-=5' }, 200)
                .animate({ top: '+=5' }, 200)
                .animate({ top: '-=5' }, 200)
                .animate({top:20}, 1500, function() {
                loop();
            });
        }
        loop();
    });

    //상단 전체보기 메뉴 열기/닫기
    jQuery("#category > h2 a").click(function(){
        jQuery(".cateTable .catebox").slideDown("fast");
    });
    jQuery("#btn_allMenuClose").click(function(){
        jQuery(".cateTable .catebox").slideUp("fast");
    });

    jQuery('.header_top form .searchheader .MS_search_word').attr( 'placeholder', '시크릿데이 브랜드 평판 1위!' );


//탑 이동버튼

jQuery(document).ready(function(){
	jQuery('.-top_sc, .aside_top').click(function(){	
	jQuery('html, body').animate({
		scrollTop:0
		},500);
	});
});
  

jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 800) {
        jQuery('.cateTable').addClass("-fix"); 
    } else {
        jQuery('.cateTable').removeClass("-fix"); 
    }
}); 





function closePop(){
    if(jQuery("input[name='top_xx']").is(":checked") ==true){
        setCookie("close","Y",1);
    }
    jQuery(".topbanner").hide();
}
jQuery(document).ready(function(){
    cookiedata = document.cookie;
    if(cookiedata.indexOf("close=Y")<0){
        jQuery(".topbanner").show();
    }else{
        jQuery(".topbanner").hide();
    }
    jQuery("#check").click(function(){
        closePop();
    });
});







  var url_pathname = window.location.pathname
    var url_search = window.location.search;
    var url = url_pathname +  url_search;
     jQuery(".cateTable .category .Left li a").each(function(){
      jQuery(this).parent().removeClass('active');
      if ( jQuery(this).attr("href") == url ){
      jQuery(this).parent().addClass("active");
      }
  });  
   