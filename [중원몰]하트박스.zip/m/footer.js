jQuery(function() { 
    var top_scroll = jQuery('.scroll_bt_tll');
    jQuery(window).scroll(function () {
        var winTop = jQuery(this).scrollTop();
        if (winTop >= 50 ) { 
            top_scroll.fadeIn('fast');
        } else if (winTop <= 50 ) { 
            top_scroll.fadeOut('fast');
        }
    }); 
});



//탑 이동버튼

jQuery(document).ready(function(){
    jQuery('.-top_sc').click(function(){    
    jQuery('html, body').animate({
        scrollTop:0
        },500);
    });
});
  