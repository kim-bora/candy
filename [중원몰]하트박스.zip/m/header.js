function mobile_homebutton(title) {
    var page_uri = "http://" + document.domain,
         main_uri = page_uri + "/m/main.html",
         icon_uri = '',
         user_agent = navigator.userAgent.toLowerCase();
    var title = (title.length > 0) ? title : shop_name,
         encode_title = encodeURI(title);

    (function($) {
        $(function() {
            $('link').each(function() {
                if ($(this).attr('rel') == "apple-touch-icon-precomposed") {
                    icon_uri = page_uri + $(this).attr('href');
                }
            });
        });
    })(jQuery);

    var call_uri= "intent://addshortcut?url="+main_uri +"&icon="+icon_uri +"&title="+encode_title+"&oq="+encode_title+"&serviceCode=nstore&version=7#Intent;scheme=naversearchapp;action=android.intent.action.VIEW;category=android.intent.category.BROWSABLE;package=com.nhn.android.search;end";
    if (user_agent.match(/ipad|iphone|ipod/g)) {
        alert('아이폰, 아이패드계열은 직접 홈버튼 추가를 사용하셔야 합니다.');
    } else {
        alert(title+'을(를) 홈화면에 추가합니다. 네이버앱이 없는 고객님께서는 네이버앱 설치페이지로 이동됩니다.');
        document.location.href = call_uri;
    }
}

jQuery("#menu").click(function(e) {
    e.preventDefault();
    if (jQuery(this).children(".fa").attr("class") == "fa fa-navicon fa-2x") {
        //var windowHeight = window.innerHeight;
        jQuery("aside, #mask").show();
        jQuery("html, body").addClass("menu_on");
        jQuery('.headerTop').addClass('top-pt-01');
        jQuery(this).children(".fa").attr("class","fa fa-times fa-2x");
    } else {
        jQuery("aside, #mask").hide();
        jQuery("html, body").removeClass("menu_on");
        jQuery('.headerTop').removeClass('top-pt-01');
        jQuery(this).children(".fa").attr("class","fa fa-navicon fa-2x");
    }
    return false
});

jQuery("aside nav .fa").click(function() {
    jQuery(this).parent().siblings().children("ul").hide();
    jQuery(this).parent().siblings().children(".fa-angle-down").removeClass("fa-rotate-180");
    jQuery(this).next("ul").toggle();

    if (jQuery(this).text() == "+") {
        jQuery(this).text("-");
    } else if (jQuery(this).text() == "-") {
        jQuery(this).text("+");
    } else {
        jQuery(this).toggleClass("fa-rotate-180");
    }
    return false
});
jQuery("#category").click(function() {
    jQuery(this).addClass("act").siblings().removeClass("act");
    jQuery(".navCategory").show();
    jQuery(".navCommunity, .navMypage").hide();
});
jQuery("#community").click(function() {
    jQuery(this).addClass("act").siblings().removeClass("act");
    jQuery(".navCommunity").show();
    jQuery(".navCategory, .navMypage").hide();
});
jQuery("#mypage").click(function() {
    jQuery(this).addClass("act").siblings().removeClass("act");
    jQuery(".navMypage").show();
    jQuery(".navCategory, .navCommunity").hide();
});
jQuery("#search").click(function() {
    jQuery("#header .search").toggle();
    jQuery("#keyword").focus()
});
jQuery("#btn_lastView").click(function() {
    jQuery("#ly_lastView").show();
});
jQuery("#ly_lastView .fa-times").click(function() {
    jQuery("#ly_lastView").hide();
});
jQuery(function() {
    jQuery("aside a[href='/m/personal.html?type=guest']").click(function(e) {
    alert(" *비회원용 문의입니다.\n 회원문의는 마이페이지를 이용하세요.");
    });
});
jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 200) {
        jQuery('.headerTop').addClass("top-pt-02");
    } else {
        jQuery('.headerTop').removeClass("top-pt-02");
    }
});





         



    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires + '; Path=/;';
    }

    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    }

    function delete_cookie(name) {
        document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    }


    




function closePop(){
    if(jQuery("input[name='top_xx']").is(":checked") ==true){
        setCookie("close","Y",1);
    }
    jQuery(".topbanner").hide();
}
jQuery(document).ready(function(){
    cookiedata = document.cookie;
    if(cookiedata.indexOf("close=Y")<0){
        jQuery(".topbanner").show();
    }else{
        jQuery(".topbanner").hide();
    }
    jQuery("#check").click(function(){
        closePop();
    });
});







jQuery(document).ready(function(){


jQuery('#sidebar').click(function(){

jQuery('#slide_sidebar').animate({left:'0'}, 450);
jQuery('#sideClose, #black_dummy').fadeIn(500);

});

jQuery('#sideClose, #black_dummy').click(function(){

jQuery('#slide_sidebar').animate({left:'-345px'}, 450);
jQuery('#sideClose, #black_dummy').fadeOut(500);

});

});



        jQuery('input#keyword').attr( 'placeholder', '시크릿데이 브랜드 평판 1위!' );


jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 200) {
        jQuery('#header .header').addClass("scroll-to-fixed-fixed"); 
    } else {
        jQuery('#header .header').removeClass("scroll-to-fixed-fixed"); 
    }
}); 
